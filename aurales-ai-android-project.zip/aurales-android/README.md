# Aurales AI — Android APK project

This project packages the existing Aurales AI all-in-one HTML page in an Android WebView using Capacitor.

## Build an APK using GitHub (phone-friendly)
1. Sign in to GitHub and create a **new private repository**.
2. Upload the contents of this folder (not the outer folder itself) to the repository. Keep `.github/workflows/build-apk.yml` included. If uploading from a phone, GitHub's website may be easier in Desktop mode.
3. Open the repository's **Actions** tab and choose **Build Aurales AI APK**.
4. Tap **Run workflow** and wait for the run to finish successfully.
5. Open the completed run and download the artifact named `aurales-ai-debug-apk`. Extract it to get `app-debug.apk`.
6. Transfer the APK to an Android device and install it. Android may ask you to allow installs from that source. Only install APKs you built or trust.

## Build locally
Requires Node.js 20+, Java 21, Android SDK, and Android build tools.

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK output: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
- This is a **debug APK** for testing, not a Play Store release. A Play Store release needs signing and additional configuration.
- The HTML is bundled locally, but any AI feature that relies on an external AI API still needs a working service and a securely handled API key. Do not put private API keys directly in the HTML or public repository.
- Login, premium, or admin screens in a standalone HTML file are not secure account/payment systems unless connected to a trusted backend.
